

const API_URL = 'http://localhost:3000/api';

const ESTADOS_ORDEN = ['pendiente', 'en_preparacion', 'listo', 'entregado'];


const ESTADO_LABEL = {
    pendiente:      'En cocina',
    en_preparacion: 'En preparación',
    listo:          'Listo para la entrega',
    entregado:      'Entregado'
};

const SIGUIENTE_ACCION = {
    pendiente:      'Empezar a preparar',
    en_preparacion: 'Marcar listo para la entrega',
    listo:          'Marcar como entregado'
};


const PROGRESO = {
    pendiente:      { paso: 1, total: 3 },
    en_preparacion: { paso: 2, total: 3 },
    listo:          { paso: 3, total: 3 },
    entregado:      { paso: 3, total: 3 }
};

let currentFilter = 'activos';
let pedidos = [];

// ── Toast de notificación ──
function mostrarToast(mesa, nuevoEstado) {
    const config = {
        listo: {
            icon: '🔔',
            title: '¡Pedido listo!',
            sub: `${mesa} — Listo para entregar`,
            clase: 'toast-listo'
        },
        entregado: {
            icon: '✅',
            title: '¡Pedido entregado!',
            sub: `${mesa} — Entregado con éxito`,
            clase: 'toast-entregado'
        }
    };

    const info = config[nuevoEstado];
    if (!info) return;

    // Eliminar toast anterior si existe
    const anterior = document.querySelector('.toast-notification');
    if (anterior) anterior.remove();

    const toast = document.createElement('div');
    toast.className = `toast-notification ${info.clase}`;
    toast.innerHTML = `
        <span class="toast-icon">${info.icon}</span>
        <div class="toast-text">
            <span class="toast-title">${info.title}</span>
            <span class="toast-sub">${info.sub}</span>
        </div>
    `;
    document.body.appendChild(toast);

    // Animar entrada
    requestAnimationFrame(() => requestAnimationFrame(() => {
        toast.classList.add('visible');
    }));

    // Auto-cerrar después de 4 segundos
    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 400);
    }, 4000);
}

function getToken() {
    return sessionStorage.getItem('servify_admin_token');
}


function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatPrice(amount) {
    return `$${Number(amount || 0).toLocaleString('es-AR')}`;
}

function formatFecha(iso) {
    const fecha = new Date(iso);
    return fecha.toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function siguienteEstado(estadoActual) {
    const index = ESTADOS_ORDEN.indexOf(estadoActual);
    if (index === -1 || index === ESTADOS_ORDEN.length - 1) return null;
    return ESTADOS_ORDEN[index + 1];
}


function crearBarraProgreso(estado) {
    const { paso, total } = PROGRESO[estado] || { paso: 0, total: 3 };

    const etapas = [
        { label: 'En cocina',    icon: '🍳' },
        { label: 'Preparando',   icon: '👨‍🍳' },
        { label: 'Listo',        icon: '✅' }
    ];

    const porcentaje = estado === 'entregado' ? 100 : (paso / total) * 100;

    const marcadoresHtml = etapas.map((e, i) => {
        const num = i + 1;
        let cls = 'bar-marker';
        if (num < paso || estado === 'entregado') cls += ' marker-done';
        else if (num === paso && estado !== 'entregado') cls += ' marker-active';
        return `
            <div class="${cls}">
                <span class="marker-icon">${num <= paso || estado === 'entregado' ? e.icon : ''}</span>
                <span class="marker-label">${e.label}</span>
            </div>`;
    }).join('');

    // Mensaje si está listo o entregado
    let bannerHtml = '';
    if (estado === 'listo') {
        bannerHtml = `
            <div class="order-ready-banner banner-listo">
                <span class="banner-icon">🔔</span>
                <span class="banner-text">¡Pedido listo para entregar!</span>
            </div>`;
    } else if (estado === 'entregado') {
        bannerHtml = `
            <div class="order-ready-banner banner-entregado">
                <span class="banner-icon">✅</span>
                <span class="banner-text">Pedido entregado con éxito</span>
            </div>`;
    }

    return `
        <div class="progress-bar-horizontal estado-bar-${escapeHtml(estado)}">
            <div class="bar-track">
                <div class="bar-fill" style="width: 0%" data-target="${porcentaje}"></div>
                <div class="bar-glow"></div>
            </div>
            <div class="bar-markers">
                ${marcadoresHtml}
            </div>
            ${bannerHtml}
        </div>`;
}


function renderItems(items) {
    return items.map(item => {
        const cantidad = Number(item.cantidad) || 1;

    
        const extras = (Array.isArray(item.ingredientes) ? item.ingredientes : [])
            .map(ing => (typeof ing === 'string' ? ing : ing && ing.nombre))
            .filter(Boolean);

        const extrasHtml = extras.length > 0
            ? `<div class="item-extras">
                   <span class="item-extras-label">Extras${cantidad > 1 ? ' (en cada una)' : ''}:</span>
                   ${extras.map(extra => `<span class="extra-chip">+ ${escapeHtml(extra)}</span>`).join('')}
               </div>`
            : `<div class="item-extras item-extras-none">Sin extras</div>`;

        return `
            <div class="order-item-row">
                <div class="order-item-main">
                    <span class="order-item-qty">${cantidad}x</span>
                    <span class="order-item-name">${escapeHtml(item.nombre)}</span>
                </div>
                ${extrasHtml}
            </div>`;
    }).join('');
}

async function cargarPedidos() {
    const alertBox = document.getElementById('ordersAlert');
    const token = getToken();

    if (!token) {
        mostrarNecesitaLogin();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/pedidos`, {
            headers: { 'Authorization': 'Bearer ' + token }
        });

        if (response.status === 401) {
            mostrarNecesitaLogin();
            return;
        }

        if (!response.ok) {
            throw new Error('No se pudieron cargar los pedidos.');
        }

        pedidos = await response.json();
        if (alertBox) alertBox.style.display = 'none';
        renderPedidos();
    } catch (error) {
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'No se pudo conectar con el servidor. ¿Está corriendo node server.js?';
            alertBox.style.display = 'block';
        }
    }
}

function mostrarNecesitaLogin() {
    const loginNotice = document.getElementById('ordersLoginNotice');
    const ordersSection = document.getElementById('ordersSection');
    if (loginNotice) loginNotice.style.display = 'flex';
    if (ordersSection) ordersSection.style.display = 'none';
}

function renderPedidos() {
    const list = document.getElementById('ordersList');
    if (!list) return;

    const visibles = currentFilter === 'activos'
        ? pedidos.filter(p => p.estado !== 'entregado')
        : pedidos;

    list.innerHTML = '';

    if (visibles.length === 0) {
        list.innerHTML = `<p class="empty-table-msg">No hay pedidos ${currentFilter === 'activos' ? 'activos' : ''} por ahora.</p>`;
        return;
    }

    visibles.forEach(pedido => {
        const items = Array.isArray(pedido.items) ? pedido.items : [];
        const estado = pedido.estado;
        const { paso, total } = PROGRESO[estado] || { paso: 0, total: 3 };
        const leyendaPaso = estado === 'entregado' ? 'Pedido cerrado' : `Paso ${paso} de ${total}`;

        const siguiente = siguienteEstado(estado);
        const accionBtn = siguiente
            ? `<button type="button" class="btn btn-primary" data-order-id="${escapeHtml(pedido.id)}" data-next-estado="${siguiente}">
                   ${SIGUIENTE_ACCION[estado]}
               </button>`
            : `<span class="badge-category">Ciclo completo</span>`;

        const card = document.createElement('article');
        card.className = `admin-card order-card order-card-${estado}`;
        card.innerHTML = `
            <div class="order-card-header">
                <div class="order-status">
                    ${crearBarraProgreso(estado)}
                    <div class="order-status-text">
                        <span class="status-pill-big estado-${escapeHtml(estado)}">${escapeHtml(ESTADO_LABEL[estado] || estado)}</span>
                        <span class="status-step">${leyendaPaso}</span>
                    </div>
                </div>
                <div class="order-card-title">
                    <strong class="prod-name">${escapeHtml(pedido.mesa)}</strong>
                    <span class="card-sub">${formatFecha(pedido.creado_at)}${pedido.retiro_mostrador ? ' · Retira en mostrador' : ''}</span>
                </div>
            </div>
            <div class="order-items">${renderItems(items)}</div>
            <div class="order-card-footer">
                <strong class="prod-price">${formatPrice(pedido.total)}</strong>
                ${accionBtn}
            </div>
        `;
        list.appendChild(card);
    });

    list.querySelectorAll('[data-order-id]').forEach(btn => {
        btn.addEventListener('click', () => {
            cambiarEstado(btn.dataset.orderId, btn.dataset.nextEstado);
        });
    });

    // Animar la barra de progreso
    requestAnimationFrame(() => requestAnimationFrame(() => {
        list.querySelectorAll('.bar-fill').forEach(bar => {
            bar.style.width = bar.dataset.target + '%';
        });
    }));
}

async function cambiarEstado(pedidoId, nuevoEstado) {
    try {
        // Buscar la mesa del pedido antes de actualizar (para el toast)
        const pedidoActual = pedidos.find(p => p.id === pedidoId);
        const mesa = pedidoActual ? pedidoActual.mesa : 'Pedido';

        const response = await fetch(`${API_URL}/pedidos/${pedidoId}/estado`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + getToken()
            },
            body: JSON.stringify({ estado: nuevoEstado })
        });

        if (!response.ok) throw new Error('No se pudo actualizar el estado.');

        // Mostrar notificación si pasó a "listo" o "entregado"
        if (nuevoEstado === 'listo' || nuevoEstado === 'entregado') {
            mostrarToast(mesa, nuevoEstado);
        }

        await cargarPedidos();
    } catch (error) {
        const alertBox = document.getElementById('ordersAlert');
        if (alertBox) {
            alertBox.className = 'admin-alert error';
            alertBox.textContent = 'No se pudo actualizar el pedido. Probá de nuevo.';
            alertBox.style.display = 'block';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    cargarPedidos();

    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentFilter = tab.dataset.filter;
            renderPedidos();
        });
    });

    const logoutBtn = document.getElementById('ordersLogoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            sessionStorage.removeItem('servify_admin_token');
            sessionStorage.removeItem('servify_admin_logged');
            window.location.href = 'pagina_vista_admin.php';
        });
    }
});